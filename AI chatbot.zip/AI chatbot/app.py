from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_message = request.json.get('message')
    response_message = generate_response(user_message)
    return jsonify({'response': response_message})

def generate_response(message):
    if 'hello' in message.lower():
        return "Hello! How can I assist you today?"
    elif 'info' in message.lower():
        return "I can help you with information about attractions and bookings."
    else:
        return "I'm sorry, I didn't understand that."

if __name__ == '__main__':
    app.run(port=5000)